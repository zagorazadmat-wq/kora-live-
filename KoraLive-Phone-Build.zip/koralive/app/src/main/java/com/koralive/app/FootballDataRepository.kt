package com.koralive.app

/**
 * نقطة الربط لمزود بيانات كرة القدم.
 *
 * قبل الاستخدام الحقيقي:
 * - اختر مزوداً يغطي البطولات المطلوبة.
 * - احتفظ بمفتاح API على خادم وسيط، لا داخل APK عام.
 * - أضف استدعاءات الشبكة، معالجة الأخطاء، التخزين المؤقت وتحديث النتائج.
 */
interface FootballDataRepository {
    suspend fun getLiveMatches(): List<Match>
    suspend fun getMatchesForToday(): List<Match>
    suspend fun getFinishedMatches(): List<Match>
}
