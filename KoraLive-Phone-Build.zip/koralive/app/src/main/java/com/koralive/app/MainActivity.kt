package com.koralive.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Forest = Color(0xFF071B16)
private val Panel = Color(0xFF10271F)
private val Lime = Color(0xFFB9F36A)
private val Muted = Color(0xFFB9CFC2)

data class Match(
    val league: String,
    val home: String,
    val away: String,
    val homeScore: String,
    val awayScore: String,
    val time: String,
    val live: Boolean
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KoraLiveApp() }
    }
}

@Composable
fun KoraLiveApp() {
    val sampleMatches = listOf(
        Match("الدوري الإنجليزي", "مانشستر سيتي", "ليفربول", "—", "—", "بيانات تجريبية", false),
        Match("الدوري الإسباني", "ريال مدريد", "برشلونة", "—", "—", "موعد المباراة", false),
        Match("الدوري المغربي", "الوداد الرياضي", "الرجاء الرياضي", "—", "—", "موعد المباراة", false),
        Match("دوري أبطال أوروبا", "بايرن ميونخ", "باريس سان جيرمان", "—", "—", "موعد المباراة", false)
    )
    var selectedTab by remember { mutableStateOf("الكل") }
    var selectedView by remember { mutableStateOf("مباشر") }
    val favorites = remember { mutableStateListOf<String>() }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Lime, background = Forest, surface = Panel,
        onPrimary = Forest, onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(Forest).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(color = Lime, shape = RoundedCornerShape(14.dp), modifier = Modifier.size(48.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Text("⚽", fontSize = 25.sp)
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("كورة لايف", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("كل المباريات في مكان واحد", color = Lime, fontSize = 13.sp)
                }
            }
            Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("مركز المباريات", color = Lime, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(5.dp))
                    Text("تابع فريقك المفضل", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("نتائج • جداول • بطولات • فرق مفضلة", color = Muted, fontSize = 13.sp)
                }
            }
            Text("البطولات", color = Color.White, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("الكل", "المغرب", "إنجلترا", "إسبانيا", "أوروبا").forEach { item ->
                    FilterChip(
                        selected = selectedTab == item,
                        onClick = { selectedTab = item },
                        label = { Text(item) }
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("مباشر", "اليوم", "النتائج").forEach { item ->
                    FilterChip(
                        selected = selectedView == item,
                        onClick = { selectedView = item },
                        label = { Text(item) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            Text("المباريات", color = Color.White, fontWeight = FontWeight.Bold)
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(sampleMatches.filter {
                    selectedTab == "الكل" ||
                    (selectedTab == "المغرب" && it.league == "الدوري المغربي") ||
                    (selectedTab == "إنجلترا" && it.league == "الدوري الإنجليزي") ||
                    (selectedTab == "إسبانيا" && it.league == "الدوري الإسباني") ||
                    (selectedTab == "أوروبا" && it.league == "دوري أبطال أوروبا")
                }) { match ->
                    MatchCard(match, favorites.contains(match.home)) {
                        if (favorites.contains(match.home)) favorites.remove(match.home)
                        else favorites.add(match.home)
                    }
                }
            }
            Text(
                "نسخة أولية: النتائج الحقيقية تحتاج ربط مزود بيانات API.",
                color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun MatchCard(match: Match, isFavorite: Boolean, onFavorite: () -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(match.league, color = Muted, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Text(if (match.live) "● مباشر" else match.time, color = if (match.live) Color(0xFFFF7777) else Muted, fontSize = 11.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(match.home, color = Color.White, modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 13.sp)
                Text("${match.homeScore} : ${match.awayScore}", color = Lime, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(match.away, color = Color.White, modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 13.sp)
                IconButton(onClick = onFavorite) {
                    Icon(if (isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                        contentDescription = "إضافة إلى المفضلة",
                        tint = if (isFavorite) Lime else Muted)
                }
            }
        }
    }
}
